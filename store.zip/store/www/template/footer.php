<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--[if IE]>
   <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<title>Интернет-магазин</title>
<link rel="stylesheet" href="/application/views/style.css" type="text/css" />
</head>
<body>
	<footer>
        <div class="wrap">
        	<aside>
                <div class="left">
                    <h3>О НАС</h3>
                    <p>Analog photo - магазин, посвященный 
    моментальной и плёночной фотографии. 
    В то время, когда фотографии уже почти 
    не печатаются, не собираются в альбомы и 
    перестали быть памятным подарком для 
    друзей и близких, мы решили возобновить 
    старые добрые традиции настоящих 
    аналоговых снимков.</p>
                </div><!--end of left-->
                
                <div class="right">
                <h3>КОНТАКТЫ</h3>
                <p>г. Киев, ул. Хельмута Ньютона, 13</p>
                <p>Телефон: +38 044 123 4567</p>
                <p>E-mail: analog.photo@gmail.com</p>
                </div><!--end of right-->
            </aside>
        </div><!--end of wrap4-->
        <div class="footercontent">
        	<div class="wrap">
                <p class = "logo2">© Analog photo 2016</p>
            </div><!--end of wrap5-->
        </div><!--end of footercontent-->
    </footer>	
	</div>
	
</body>
</html>